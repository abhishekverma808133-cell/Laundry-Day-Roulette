// Initial seed data for Laundry Day Roulette Prototype
const INITIAL_ORDERS = [
  {
    id: "LDR-1021",
    studentName: "Aarav Sharma",
    roomNumber: "B-304",
    phone: "+91 98765 43210",
    totalClothes: 14,
    items: {
      shirts: 5,
      pants: 4,
      tshirts: 3,
      bedding: 1,
      towels: 1
    },
    laundryType: "Wash & Fold",
    specialNotes: "Use mild detergent for blue shirts",
    submittedDate: "2026-11-23 10:30 AM",
    pickupDate: "2026-11-25 05:00 PM",
    status: "Washing", // Options: Collected, Washing, Ready for pickup, Delivered
    machineNo: "Machine #3",
    rackLocation: "Rack A-04",
    staffNotes: "Spin cycle scheduled at 2:00 PM"
  },
  {
    id: "LDR-1022",
    studentName: "Priya Patel",
    roomNumber: "G-112",
    phone: "+91 91234 56789",
    totalClothes: 8,
    items: {
      shirts: 2,
      pants: 2,
      tshirts: 2,
      bedding: 0,
      towels: 2
    },
    laundryType: "Wash & Iron",
    specialNotes: "Crisp collar crease needed",
    submittedDate: "2026-11-22 09:15 AM",
    pickupDate: "2026-11-24 04:00 PM",
    status: "Ready for pickup",
    machineNo: "Machine #1",
    rackLocation: "Rack C-12",
    staffNotes: "Ironed and bagged with hanger"
  },
  {
    id: "LDR-1023",
    studentName: "Rohan Verma",
    roomNumber: "H-208",
    phone: "+91 99887 76655",
    totalClothes: 22,
    items: {
      shirts: 6,
      pants: 6,
      tshirts: 5,
      bedding: 3,
      towels: 2
    },
    laundryType: "Express Wash",
    specialNotes: "Football jersey - no high heat",
    submittedDate: "2026-11-24 08:45 AM",
    pickupDate: "2026-11-24 08:00 PM",
    status: "Collected",
    machineNo: "Queue slot #2",
    rackLocation: "Intake Bin 2",
    staffNotes: "Pre-treated stain on white jersey"
  },
  {
    id: "LDR-1018",
    studentName: "Sneha Reddy",
    roomNumber: "G-205",
    phone: "+91 98450 12345",
    totalClothes: 11,
    items: {
      shirts: 4,
      pants: 3,
      tshirts: 2,
      bedding: 1,
      towels: 1
    },
    laundryType: "Dry Cleaning",
    specialNotes: "Woolen blazer included",
    submittedDate: "2026-11-20 11:00 AM",
    pickupDate: "2026-11-22 06:00 PM",
    status: "Delivered",
    machineNo: "Dry Clean Unit #1",
    rackLocation: "Delivered",
    staffNotes: "Handed over to student with verification code"
  },
  {
    id: "LDR-1015",
    studentName: "Ananya Iyer",
    roomNumber: "F-102",
    phone: "+91 97112 33445",
    totalClothes: 16,
    items: {
      shirts: 6,
      pants: 4,
      tshirts: 4,
      bedding: 1,
      towels: 1
    },
    laundryType: "Wash & Fold",
    specialNotes: "None",
    submittedDate: "2026-11-18 04:30 PM",
    pickupDate: "2026-11-20 02:00 PM",
    status: "Delivered",
    machineNo: "Machine #4",
    rackLocation: "Delivered",
    staffNotes: "Completed on schedule"
  }
];

const INITIAL_COMPLAINTS = [
  {
    id: "CMP-401",
    orderId: "LDR-1018",
    studentName: "Sneha Reddy",
    roomNumber: "G-205",
    type: "Missing clothes", // Missing clothes, Damaged clothes, Late delivery, Wrong clothes, Other
    description: "One yellow scarf was listed in the drop-off count but was not inside the delivered laundry bag.",
    submittedDate: "2026-11-22 07:15 PM",
    status: "Under Investigation", // Pending, Under Investigation, Resolved
    staffResponse: "Staff checked lost & found basket near dryer #2. Item spotted, ready for collection at desk."
  },
  {
    id: "CMP-402",
    orderId: "LDR-1015",
    studentName: "Ananya Iyer",
    roomNumber: "F-102",
    type: "Late delivery",
    description: "Laundry was promised by 2:00 PM but counter was closed until 5:00 PM.",
    submittedDate: "2026-11-20 06:00 PM",
    status: "Resolved",
    staffResponse: "Apologies for the delay caused by power maintenance. Compensation voucher issued."
  }
];
