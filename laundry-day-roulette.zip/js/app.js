// ==========================================================================
// Laundry Day Roulette - Core Web App JavaScript
// Handles state, LocalStorage, routing, order lifecycle, & role simulation
// ==========================================================================

let orders = [];
let complaints = [];
let currentRole = 'student';
let activeStaffStatusFilter = 'all';

// Initialize App on DOM Load
document.addEventListener('DOMContentLoaded', () => {
  initStorage();
  initDefaultDates();
  setupEventListeners();
  renderAllViews();
  // Check URL hash for direct routing if any
  const hash = window.location.hash.replace('#', '');
  if (hash && document.getElementById(`page-${hash}`)) {
    navigateTo(hash);
  } else {
    navigateTo('home');
  }
});

// --------------------------------------------------------------------------
// Storage & Data Initialization
// --------------------------------------------------------------------------
function initStorage() {
  const storedOrders = localStorage.getItem('ldr_orders');
  const storedComplaints = localStorage.getItem('ldr_complaints');

  if (storedOrders) {
    try {
      orders = JSON.parse(storedOrders);
    } catch (e) {
      orders = [...INITIAL_ORDERS];
      saveOrders();
    }
  } else {
    orders = [...INITIAL_ORDERS];
    saveOrders();
  }

  if (storedComplaints) {
    try {
      complaints = JSON.parse(storedComplaints);
    } catch (e) {
      complaints = [...INITIAL_COMPLAINTS];
      saveComplaints();
    }
  } else {
    complaints = [...INITIAL_COMPLAINTS];
    saveComplaints();
  }
}

function saveOrders() {
  localStorage.setItem('ldr_orders', JSON.stringify(orders));
}

function saveComplaints() {
  localStorage.setItem('ldr_complaints', JSON.stringify(complaints));
}

function resetSeedData() {
  if (confirm("Reset prototype data back to original sample orders & complaints?")) {
    orders = [...INITIAL_ORDERS];
    complaints = [...INITIAL_COMPLAINTS];
    saveOrders();
    saveComplaints();
    renderAllViews();
    showToast("Prototype sample data reset successfully!", "success");
  }
}

// --------------------------------------------------------------------------
// Navigation & Routing
// --------------------------------------------------------------------------
function navigateTo(pageId) {
  // Hide all pages
  document.querySelectorAll('.page-view').forEach(page => {
    page.classList.remove('active');
  });

  // Show target page
  const targetPage = document.getElementById(`page-${pageId}`);
  if (targetPage) {
    targetPage.classList.add('active');
    window.location.hash = pageId;
  }

  // Update navbar links
  document.querySelectorAll('#navLinksList .nav-link').forEach(link => {
    if (link.getAttribute('data-page') === pageId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Close mobile menu if open
  const navList = document.getElementById('navLinksList');
  if (navList) navList.classList.remove('mobile-open');

  // Trigger page-specific refreshes
  if (pageId === 'student-dash') {
    renderStudentDashboard();
  } else if (pageId === 'staff-dash') {
    renderStaffDashboard();
  } else if (pageId === 'complaints') {
    renderComplaintsList();
  } else if (pageId === 'history') {
    renderHistoryTable();
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function toggleMobileMenu() {
  const navList = document.getElementById('navLinksList');
  if (navList) {
    navList.classList.toggle('mobile-open');
  }
}

// --------------------------------------------------------------------------
// Role Switcher (Student vs Staff)
// --------------------------------------------------------------------------
function switchRole(role) {
  currentRole = role;
  const btnStudent = document.getElementById('roleBtnStudent');
  const btnStaff = document.getElementById('roleBtnStaff');
  const indicator = document.getElementById('roleStatusIndicator');

  if (role === 'student') {
    btnStudent.classList.add('active');
    btnStaff.classList.remove('active');
    indicator.textContent = '● Student Mode Active';
    indicator.style.color = '#4ade80';
    indicator.style.background = 'rgba(34, 197, 94, 0.2)';
    showToast("Switched to Student Experience", "success");
  } else {
    btnStaff.classList.add('active');
    btnStudent.classList.remove('active');
    indicator.textContent = '● Staff Admin Mode Active';
    indicator.style.color = '#38bdf8';
    indicator.style.background = 'rgba(56, 189, 248, 0.2)';
    showToast("Switched to Staff Management Portal", "success");
  }
}

// --------------------------------------------------------------------------
// View Rendering & KPI Updates
// --------------------------------------------------------------------------
function renderAllViews() {
  renderStudentDashboard();
  renderStaffDashboard();
  renderComplaintsList();
  renderHistoryTable();
  updateHomeStats();
}

function updateHomeStats() {
  const totalWashed = orders.reduce((sum, o) => sum + (o.totalClothes || 0), 1250);
  const counterEl = document.getElementById('statTotalCounter');
  if (counterEl) {
    counterEl.textContent = `${totalWashed.toLocaleString()}+`;
  }
}

// 1. Student Dashboard
function renderStudentDashboard() {
  const total = orders.length;
  const collected = orders.filter(o => o.status === 'Collected').length;
  const washing = orders.filter(o => o.status === 'Washing').length;
  const ready = orders.filter(o => o.status === 'Ready for pickup').length;
  const delivered = orders.filter(o => o.status === 'Delivered').length;

  // KPI elements
  const elTotal = document.getElementById('kpiTotalOrders');
  const elCol = document.getElementById('kpiCollected');
  const elWash = document.getElementById('kpiWashing');
  const elReady = document.getElementById('kpiReady');
  const elDel = document.getElementById('kpiDelivered');

  if (elTotal) elTotal.textContent = total;
  if (elCol) elCol.textContent = collected;
  if (elWash) elWash.textContent = washing;
  if (elReady) elReady.textContent = ready;
  if (elDel) elDel.textContent = delivered;

  // Active Orders Table (active if not delivered, or recent)
  const tbody = document.getElementById('studentOrdersTableBody');
  if (!tbody) return;

  const activeOrders = orders.filter(o => o.status !== 'Delivered');
  // If no active, display the top 3 latest
  const displayList = activeOrders.length > 0 ? activeOrders : orders.slice(0, 3);

  if (displayList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--slate-500);">No active laundry orders. <a href="javascript:void(0)" onclick="navigateTo('submit-laundry')" style="color:var(--primary); font-weight:600;">Submit one now</a>!</td></tr>`;
    return;
  }

  tbody.innerHTML = displayList.map(order => `
    <tr>
      <td>
        <span class="id-badge" style="cursor:pointer;" onclick="trackSpecificOrder('${order.id}')" title="Click to track">${order.id}</span>
      </td>
      <td>
        <strong>${escapeHtml(order.studentName)}</strong>
        <div style="font-size:0.78rem; color:var(--slate-500);">${escapeHtml(order.roomNumber)}</div>
      </td>
      <td><strong>${order.totalClothes}</strong> pcs</td>
      <td><span style="font-size:0.85rem; color:var(--slate-600);">${order.laundryType}</span></td>
      <td>${getStatusBadge(order.status)}</td>
      <td style="font-size:0.85rem;">${order.pickupDate || 'TBD'}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary" onclick="trackSpecificOrder('${order.id}')">
          Track
        </button>
      </td>
    </tr>
  `).join('');
}

// --------------------------------------------------------------------------
// Tracking System
// --------------------------------------------------------------------------
function quickTrackOrder() {
  const input = document.getElementById('quickTrackInput');
  const id = input.value.trim().toUpperCase();
  if (!id) {
    showToast("Please enter a Laundry ID", "error");
    return;
  }
  trackSpecificOrder(id);
}

function quickFillTrack(id) {
  const input = document.getElementById('quickTrackInput');
  if (input) input.value = id;
  trackSpecificOrder(id);
}

function trackSample(id) {
  const input = document.getElementById('trackInput');
  if (input) input.value = id;
  trackSpecificOrder(id);
}

function performTrack() {
  const input = document.getElementById('trackInput');
  const id = input.value.trim().toUpperCase();
  if (!id) {
    showToast("Please enter a Laundry ID to track", "error");
    return;
  }
  trackSpecificOrder(id);
}

function trackSpecificOrder(id) {
  navigateTo('track-laundry');
  const trackInput = document.getElementById('trackInput');
  if (trackInput) trackInput.value = id;

  const order = orders.find(o => o.id.toUpperCase() === id.toUpperCase());
  const resultBox = document.getElementById('trackingResultBox');
  const notFoundBox = document.getElementById('trackingNotFoundBox');

  if (!order) {
    if (resultBox) resultBox.classList.remove('active');
    if (notFoundBox) notFoundBox.style.display = 'block';
    return;
  }

  if (notFoundBox) notFoundBox.style.display = 'none';
  if (resultBox) resultBox.classList.add('active');

  // Populate Details
  document.getElementById('trackDisplayId').textContent = order.id;
  document.getElementById('trackDisplayBadge').innerHTML = getStatusBadge(order.status);
  document.getElementById('trackStudentName').textContent = order.studentName;
  document.getElementById('trackRoomNo').textContent = order.roomNumber;
  document.getElementById('trackPickupDate').textContent = order.pickupDate || 'Standard turnaround';
  document.getElementById('trackServiceType').textContent = order.laundryType;
  document.getElementById('trackTotalClothes').textContent = `${order.totalClothes} Items`;
  document.getElementById('trackMachine').textContent = order.machineNo || 'Pending Allocation';
  document.getElementById('trackRack').textContent = order.rackLocation || 'Intake Counter';
  document.getElementById('trackDropTime').textContent = order.submittedDate || 'Recent';
  document.getElementById('trackStaffNotes').textContent = order.staffNotes || 'Processing according to standard schedule.';

  // Breakdown tags
  const breakdownContainer = document.getElementById('trackBreakdownPills');
  if (breakdownContainer && order.items) {
    const items = order.items;
    let pills = [];
    if (items.shirts) pills.push(`<span class="item-pill">👔 Shirts: ${items.shirts}</span>`);
    if (items.pants) pills.push(`<span class="item-pill">👖 Pants: ${items.pants}</span>`);
    if (items.tshirts) pills.push(`<span class="item-pill">👕 T-Shirts: ${items.tshirts}</span>`);
    if (items.bedding) pills.push(`<span class="item-pill">🛏️ Bedding: ${items.bedding}</span>`);
    if (items.towels) pills.push(`<span class="item-pill">🧖 Towels: ${items.towels}</span>`);
    breakdownContainer.innerHTML = pills.join(' ');
  }

  // Update Stepper
  updateStepperState(order.status);
}

function updateStepperState(status) {
  const steps = [
    { id: 'step-collected', name: 'Collected', progress: 15 },
    { id: 'step-washing', name: 'Washing', progress: 48 },
    { id: 'step-ready', name: 'Ready for pickup', progress: 80 },
    { id: 'step-delivered', name: 'Delivered', progress: 100 }
  ];

  const fill = document.getElementById('stepperFill');
  const statusIndexMap = {
    'Collected': 0,
    'Washing': 1,
    'Ready for pickup': 2,
    'Delivered': 3
  };

  const currentIndex = statusIndexMap[status] !== undefined ? statusIndexMap[status] : 0;

  steps.forEach((step, idx) => {
    const stepEl = document.getElementById(step.id);
    if (!stepEl) return;

    stepEl.classList.remove('completed', 'active');
    const circle = stepEl.querySelector('.stepper-step-circle');

    if (idx < currentIndex) {
      stepEl.classList.add('completed');
      if (circle) circle.innerHTML = '✓';
    } else if (idx === currentIndex) {
      stepEl.classList.add('active');
      if (circle) circle.innerHTML = (idx + 1);
    } else {
      if (circle) circle.innerHTML = (idx + 1);
    }
  });

  if (fill) {
    fill.style.width = `${steps[currentIndex].progress}%`;
  }
}

function initComplaintForOrder() {
  const currentId = document.getElementById('trackDisplayId').textContent;
  const order = orders.find(o => o.id === currentId);

  navigateTo('complaints');
  const cmpOrderIdInput = document.getElementById('cmpOrderId');
  const cmpStudentNameInput = document.getElementById('cmpStudentName');
  const cmpRoomInput = document.getElementById('cmpRoomNumber');

  if (cmpOrderIdInput) cmpOrderIdInput.value = currentId;
  if (order) {
    if (cmpStudentNameInput) cmpStudentNameInput.value = order.studentName;
    if (cmpRoomInput) cmpRoomInput.value = order.roomNumber;
  }
}

// --------------------------------------------------------------------------
// Laundry Registration (Submit Form)
// --------------------------------------------------------------------------
function calculateTotalClothes() {
  const shirts = parseInt(document.getElementById('countShirts').value) || 0;
  const pants = parseInt(document.getElementById('countPants').value) || 0;
  const tshirts = parseInt(document.getElementById('countTshirts').value) || 0;
  const bedding = parseInt(document.getElementById('countBedding').value) || 0;
  const towels = parseInt(document.getElementById('countTowels').value) || 0;

  const total = shirts + pants + tshirts + bedding + towels;
  const display = document.getElementById('regTotalDisplay');
  if (display) display.textContent = total;
  return total;
}

function handleLaundrySubmit(event) {
  event.preventDefault();

  const studentName = document.getElementById('regStudentName').value.trim();
  const roomNumber = document.getElementById('regRoomNumber').value.trim();
  const phone = document.getElementById('regPhone').value.trim();
  const pickupDateRaw = document.getElementById('regPickupDate').value;
  const laundryType = document.querySelector('input[name="laundryType"]:checked').value;
  const specialNotes = document.getElementById('regSpecialNotes').value.trim();

  const shirts = parseInt(document.getElementById('countShirts').value) || 0;
  const pants = parseInt(document.getElementById('countPants').value) || 0;
  const tshirts = parseInt(document.getElementById('countTshirts').value) || 0;
  const bedding = parseInt(document.getElementById('countBedding').value) || 0;
  const towels = parseInt(document.getElementById('countTowels').value) || 0;
  const totalClothes = shirts + pants + tshirts + bedding + towels;

  if (totalClothes <= 0) {
    showToast("Please enter at least 1 item in the clothes count", "error");
    return;
  }

  // Format pickup date
  let formattedPickup = pickupDateRaw;
  if (pickupDateRaw) {
    const d = new Date(pickupDateRaw);
    formattedPickup = d.toLocaleString('en-US', {
      month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
    });
  }

  // Generate unique Laundry ID
  const newId = generateUniqueLaundryId();
  const now = new Date();
  const submittedDate = now.toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
  });

  const newOrder = {
    id: newId,
    studentName,
    roomNumber,
    phone,
    totalClothes,
    items: { shirts, pants, tshirts, bedding, towels },
    laundryType,
    specialNotes: specialNotes || "None",
    submittedDate,
    pickupDate: formattedPickup,
    status: "Collected",
    machineNo: "Queue Slot #" + (Math.floor(Math.random() * 5) + 1),
    rackLocation: "Intake Counter Desk",
    staffNotes: "Drop-off recorded. Inspection in progress."
  };

  orders.unshift(newOrder);
  saveOrders();
  renderAllViews();

  // Reset form
  document.getElementById('laundryRegForm').reset();
  calculateTotalClothes();

  // Show Success Modal
  document.getElementById('modalGeneratedId').textContent = newId;
  openModal('orderSuccessModal');
  showToast(`Laundry registered! Your ID is ${newId}`, "success");
}

function generateUniqueLaundryId() {
  let id;
  let exists = true;
  while (exists) {
    const num = Math.floor(1000 + Math.random() * 9000);
    id = `LDR-${num}`;
    exists = orders.some(o => o.id === id);
  }
  return id;
}

function copyModalId() {
  const id = document.getElementById('modalGeneratedId').textContent;
  navigator.clipboard.writeText(id).then(() => {
    showToast(`Copied ${id} to clipboard!`, "success");
  }).catch(() => {
    showToast(`Laundry ID: ${id}`, "success");
  });
}

function trackFromModal() {
  const id = document.getElementById('modalGeneratedId').textContent;
  closeModal('orderSuccessModal');
  trackSpecificOrder(id);
}

// --------------------------------------------------------------------------
// Complaints System
// --------------------------------------------------------------------------
function handleComplaintSubmit(event) {
  event.preventDefault();

  const orderId = document.getElementById('cmpOrderId').value.trim().toUpperCase();
  const studentName = document.getElementById('cmpStudentName').value.trim();
  const roomNumber = document.getElementById('cmpRoomNumber').value.trim();
  const type = document.getElementById('cmpType').value;
  const description = document.getElementById('cmpDescription').value.trim();

  const num = Math.floor(100 + Math.random() * 900);
  const newCmpId = `CMP-${num}`;
  const now = new Date();
  const submittedDate = now.toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
  });

  const newComplaint = {
    id: newCmpId,
    orderId,
    studentName,
    roomNumber,
    type,
    description,
    submittedDate,
    status: "Pending",
    staffResponse: ""
  };

  complaints.unshift(newComplaint);
  saveComplaints();
  renderComplaintsList();
  renderStaffDashboard();

  document.getElementById('complaintForm').reset();
  showToast(`Complaint ${newCmpId} submitted to staff desk`, "success");
}

function renderComplaintsList() {
  const container = document.getElementById('complaintsListContainer');
  const countBadge = document.getElementById('complaintsCountBadge');
  if (countBadge) countBadge.textContent = `${complaints.length} Total`;
  if (!container) return;

  if (complaints.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:30px; color:var(--slate-500);">No complaints logged yet.</div>`;
    return;
  }

  container.innerHTML = complaints.map(c => `
    <div class="complaint-card-item">
      <div class="complaint-header-row">
        <div>
          <span class="complaint-type-pill">${escapeHtml(c.type)}</span>
          <span class="id-badge" style="margin-left:8px; font-size:0.75rem;">Order: ${c.orderId}</span>
        </div>
        ${getComplaintStatusBadge(c.status)}
      </div>

      <p class="complaint-desc">${escapeHtml(c.description)}</p>

      <div style="font-size:0.78rem; color:var(--slate-500); display:flex; justify-content:space-between; align-items:center;">
        <span>By <strong>${escapeHtml(c.studentName)}</strong> (${escapeHtml(c.roomNumber)})</span>
        <span>${c.submittedDate}</span>
      </div>

      ${c.staffResponse ? `
        <div class="staff-response-box">
          <strong>Staff Action:</strong> ${escapeHtml(c.staffResponse)}
        </div>
      ` : `
        <div style="font-size:0.75rem; color:#b45309; margin-top:8px; display:flex; align-items:center; gap:4px;">
          ⏳ Awaiting staff review at the laundry counter
        </div>
      `}
    </div>
  `).join('');
}

// --------------------------------------------------------------------------
// Staff Dashboard & Actions
// --------------------------------------------------------------------------
function renderStaffDashboard() {
  // Update Metrics
  const activeCount = orders.filter(o => o.status !== 'Delivered').length;
  const washingCount = orders.filter(o => o.status === 'Washing').length;
  const readyCount = orders.filter(o => o.status === 'Ready for pickup').length;
  const openComplaintsCount = complaints.filter(c => c.status !== 'Resolved').length;

  const sTotal = document.getElementById('staffStatTotalOrders');
  const sWash = document.getElementById('staffStatWashingOrders');
  const sReady = document.getElementById('staffStatReadyOrders');
  const sCmp = document.getElementById('staffStatPendingComplaints');

  if (sTotal) sTotal.textContent = activeCount;
  if (sWash) sWash.textContent = washingCount;
  if (sReady) sReady.textContent = readyCount;
  if (sCmp) sCmp.textContent = openComplaintsCount;

  filterStaffOrders();
  renderStaffComplaints();
}

function setStaffFilter(status, btnElement) {
  activeStaffStatusFilter = status;
  document.querySelectorAll('.status-tab-btn').forEach(b => b.classList.remove('active'));
  if (btnElement) btnElement.classList.add('active');
  filterStaffOrders();
}

function filterStaffOrders() {
  const searchTerm = (document.getElementById('staffOrderSearch')?.value || '').toLowerCase().trim();
  const tbody = document.getElementById('staffOrdersTableBody');
  if (!tbody) return;

  let filtered = orders.filter(order => {
    const matchesFilter = (activeStaffStatusFilter === 'all') || (order.status === activeStaffStatusFilter);
    const matchesSearch = !searchTerm ||
      order.id.toLowerCase().includes(searchTerm) ||
      order.studentName.toLowerCase().includes(searchTerm) ||
      order.roomNumber.toLowerCase().includes(searchTerm);
    return matchesFilter && matchesSearch;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:24px; color:var(--slate-500);">No orders found matching criteria.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(order => `
    <tr>
      <td><span class="id-badge">${order.id}</span></td>
      <td><strong>${escapeHtml(order.studentName)}</strong></td>
      <td>${escapeHtml(order.roomNumber)}</td>
      <td>${order.totalClothes} pcs</td>
      <td><span style="font-size:0.82rem;">${order.laundryType}</span></td>
      <td>${getStatusBadge(order.status)}</td>
      <td style="font-size:0.82rem;">
        <div>${order.machineNo || 'None'}</div>
        <div style="color:var(--slate-400);">${order.rackLocation || 'Unassigned'}</div>
      </td>
      <td>
        <select class="form-control" style="padding:4px 8px; font-size:0.82rem; height:auto; width:130px;" onchange="inlineChangeStatus('${order.id}', this.value)">
          <option value="Collected" ${order.status === 'Collected' ? 'selected' : ''}>Collected</option>
          <option value="Washing" ${order.status === 'Washing' ? 'selected' : ''}>Washing</option>
          <option value="Ready for pickup" ${order.status === 'Ready for pickup' ? 'selected' : ''}>Ready</option>
          <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
        </select>
      </td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="openStaffEditModal('${order.id}')" title="Edit Machine & Rack Details">
          ⚙️ Edit
        </button>
      </td>
    </tr>
  `).join('');
}

function inlineChangeStatus(orderId, newStatus) {
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  order.status = newStatus;
  if (newStatus === 'Ready for pickup' && (!order.rackLocation || order.rackLocation.includes('Intake'))) {
    order.rackLocation = 'Rack B-' + Math.floor(Math.random() * 20 + 1);
  }
  saveOrders();
  renderAllViews();
  showToast(`Order ${orderId} updated to: ${newStatus}`, "success");
}

function openStaffEditModal(orderId) {
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  document.getElementById('staffModalHiddenId').value = order.id;
  document.getElementById('staffModalOrderId').textContent = order.id;
  document.getElementById('staffModalStatus').value = order.status;
  document.getElementById('staffModalMachine').value = order.machineNo || '';
  document.getElementById('staffModalRack').value = order.rackLocation || '';
  document.getElementById('staffModalPickupDate').value = order.pickupDate || '';
  document.getElementById('staffModalNotes').value = order.staffNotes || '';

  openModal('staffUpdateModal');
}

function handleStaffUpdateSave(event) {
  event.preventDefault();
  const id = document.getElementById('staffModalHiddenId').value;
  const order = orders.find(o => o.id === id);
  if (!order) return;

  order.status = document.getElementById('staffModalStatus').value;
  order.machineNo = document.getElementById('staffModalMachine').value;
  order.rackLocation = document.getElementById('staffModalRack').value;
  order.pickupDate = document.getElementById('staffModalPickupDate').value;
  order.staffNotes = document.getElementById('staffModalNotes').value;

  saveOrders();
  renderAllViews();
  closeModal('staffUpdateModal');
  showToast(`Updated details for order ${id}`, "success");
}

function renderStaffComplaints() {
  const tbody = document.getElementById('staffComplaintsTableBody');
  if (!tbody) return;

  if (complaints.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:20px; color:var(--slate-500);">No complaints logged.</td></tr>`;
    return;
  }

  tbody.innerHTML = complaints.map(c => `
    <tr>
      <td><span class="id-badge">${c.id}</span></td>
      <td><span class="id-badge" style="background:#f1f5f9; color:var(--slate-600); cursor:pointer;" onclick="trackSpecificOrder('${c.orderId}')">${c.orderId}</span></td>
      <td><strong>${escapeHtml(c.studentName)}</strong> (${escapeHtml(c.roomNumber)})</td>
      <td><span class="complaint-type-pill">${escapeHtml(c.type)}</span></td>
      <td style="max-width:240px; font-size:0.85rem; line-height:1.3;">
        ${escapeHtml(c.description)}
        ${c.staffResponse ? `<div style="font-size:0.75rem; color:#2563eb; margin-top:4px;"><strong>Reply:</strong> ${escapeHtml(c.staffResponse)}</div>` : ''}
      </td>
      <td>${getComplaintStatusBadge(c.status)}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary" onclick="openStaffComplaintModal('${c.id}')">
          Resolve
        </button>
      </td>
    </tr>
  `).join('');
}

function openStaffComplaintModal(complaintId) {
  const complaint = complaints.find(c => c.id === complaintId);
  if (!complaint) return;

  document.getElementById('staffCmpHiddenId').value = complaint.id;
  document.getElementById('staffCmpModalId').textContent = complaint.id;
  document.getElementById('staffCmpModalType').textContent = complaint.type;
  document.getElementById('staffCmpModalDesc').textContent = complaint.description;
  document.getElementById('staffCmpStatus').value = complaint.status;
  document.getElementById('staffCmpResolutionNote').value = complaint.staffResponse || '';

  openModal('staffComplaintModal');
}

function handleStaffComplaintSave(event) {
  event.preventDefault();
  const id = document.getElementById('staffCmpHiddenId').value;
  const complaint = complaints.find(c => c.id === id);
  if (!complaint) return;

  complaint.status = document.getElementById('staffCmpStatus').value;
  complaint.staffResponse = document.getElementById('staffCmpResolutionNote').value;

  saveComplaints();
  renderComplaintsList();
  renderStaffDashboard();
  closeModal('staffComplaintModal');
  showToast(`Complaint ${id} status updated to: ${complaint.status}`, "success");
}

// --------------------------------------------------------------------------
// History Page
// --------------------------------------------------------------------------
function filterHistoryOrders() {
  const searchTerm = (document.getElementById('historySearchInput')?.value || '').toLowerCase().trim();
  const statusFilter = document.getElementById('historyStatusFilter')?.value || 'all';
  renderHistoryTable(searchTerm, statusFilter);
}

function renderHistoryTable(searchTerm = '', statusFilter = 'all') {
  const tbody = document.getElementById('historyTableBody');
  if (!tbody) return;

  let filtered = orders.filter(o => {
    const matchesStatus = (statusFilter === 'all') || (o.status === statusFilter);
    const matchesSearch = !searchTerm ||
      o.id.toLowerCase().includes(searchTerm) ||
      o.studentName.toLowerCase().includes(searchTerm) ||
      o.roomNumber.toLowerCase().includes(searchTerm);
    return matchesStatus && matchesSearch;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:30px; color:var(--slate-500);">No orders found matching search.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(o => `
    <tr>
      <td><span class="id-badge">${o.id}</span></td>
      <td><strong>${escapeHtml(o.studentName)}</strong></td>
      <td>${escapeHtml(o.roomNumber)}</td>
      <td>${o.totalClothes} items</td>
      <td>${o.laundryType}</td>
      <td style="font-size:0.82rem; color:var(--slate-500);">${o.submittedDate || '-'}</td>
      <td style="font-size:0.82rem; color:var(--slate-500);">${o.pickupDate || '-'}</td>
      <td>${getStatusBadge(o.status)}</td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="trackSpecificOrder('${o.id}')">
          View
        </button>
      </td>
    </tr>
  `).join('');
}

// --------------------------------------------------------------------------
// UI Helpers, Badges, Modals, Toasts
// --------------------------------------------------------------------------
function getStatusBadge(status) {
  switch (status) {
    case 'Collected':
      return `<span class="badge badge-collected"><span class="status-dot"></span>Collected</span>`;
    case 'Washing':
      return `<span class="badge badge-washing"><span class="status-dot"></span>Washing</span>`;
    case 'Ready for pickup':
      return `<span class="badge badge-ready"><span class="status-dot"></span>Ready for Pickup</span>`;
    case 'Delivered':
      return `<span class="badge badge-delivered"><span class="status-dot"></span>Delivered</span>`;
    default:
      return `<span class="badge" style="background:#e2e8f0; color:#475569;">${status}</span>`;
  }
}

function getComplaintStatusBadge(status) {
  switch (status) {
    case 'Pending':
      return `<span class="badge badge-complaint-pending">Pending</span>`;
    case 'Under Investigation':
      return `<span class="badge badge-complaint-investigating">Investigating</span>`;
    case 'Resolved':
      return `<span class="badge badge-complaint-resolved">✓ Resolved</span>`;
    default:
      return `<span class="badge">${status}</span>`;
  }
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('active');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('active');
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : '⚠️'}</span>
    <span>${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

function initDefaultDates() {
  const pickupInput = document.getElementById('regPickupDate');
  if (pickupInput) {
    // Set default pickup date to 24 hours in the future
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(17, 0, 0, 0); // 5:00 PM tomorrow
    const isoStr = tomorrow.toISOString().slice(0, 16);
    pickupInput.value = isoStr;
  }
}

function setupEventListeners() {
  // Modal overlay click outside closes modal
  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  });
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
