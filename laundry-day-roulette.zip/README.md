# 🧺 Laundry Day Roulette — Campus Smart Laundry Web App (P21 Prototype)

A modern, responsive, digital web application prototype for campus hostel laundry management. Built with **HTML5, CSS3, and JavaScript**, featuring real-time state management via `localStorage`.

---

## 📌 Project Overview
Hostel students often face lost clothes, long counter queues, uncertain pickup timings, and manual paper-slip hassles. **Laundry Day Roulette** replaces chaos with a digital-first workflow:

1. **Student registers laundry online** and receives an instant unique Laundry ID (e.g., `LDR-1021`).
2. **Student drops off the clothes bag** at the counter.
3. **Laundry staff updates status** in real time (`Collected` ➔ `Washing` ➔ `Ready for pickup` ➔ `Delivered`).
4. **Student tracks progress** via an interactive stepper and collects clean clothes with zero friction.
5. **Integrated Complaint System** for missing clothes, damaged garments, or delay resolution.

---

## 🚀 The 7 Pages & Features (Matching Project Spec)

| # | Page | Key Functionality |
|---|---|---|
| **1** | **Home Page** | Project branding, Hero section, Instant ID quick tracker, 4-step "How It Works" workflow, stats overview. |
| **2** | **Student Dashboard** | 5 Key Performance Indicator (KPI) cards: Total Orders, Collected, Washing, Ready for pickup, Delivered; active orders list; quick shortcuts. |
| **3** | **Laundry Tracking** | Instant ID search with visual progress stepper (Collected ➔ Washing ➔ Ready ➔ Delivered), itemized clothes breakdown, machine number, rack location, and staff operational notes. |
| **4** | **Submit Laundry** | Student drop-off registration: Student name, room number, phone/WhatsApp, itemized clothes counter (shirts, pants, bed linen, towels), service type selection, preferred pickup date/time, special instructions. Generates a unique `LDR-XXXX` ID. |
| **5** | **Complaint System** | File grievances for Missing clothes, Damaged clothes, Late delivery, Wrong clothes. View logged complaints with live status (`Pending`, `Under Investigation`, `Resolved`) and staff responses. |
| **6** | **Staff Dashboard** | Staff admin portal with live metrics, search & filter by status, 1-click status transitions, machine & rack allocation modal, and complaint resolution desk. |
| **7** | **History** | Searchable archive of all completed and past laundry records with filtering by status and date. |

---

## 💻 Tech Stack
- **HTML5**: Semantic web structure across all 7 views.
- **CSS3**: Modern SaaS aesthetic inspired by *Speediwash* & *LaundryPro*, featuring responsive flexbox/grid, custom animations, status pills, and interactive steppers.
- **JavaScript (ES6+)**: SPA-style client routing, state management, unique ID generation, and validation.
- **Browser LocalStorage**: Full real-time persistence — updates made by staff instantly reflect in the student dashboard and tracking without a backend!
- *(Future integration)*: Firebase Firestore for cloud sync and Netlify/Vercel for public deployment.

---

## 📂 Project Structure
```
laundry-day-roulette/
├── index.html            # Main Single-Page Web Application
├── css/
│   └── styles.css        # Modern responsive design & themes
├── js/
│   ├── seedData.js       # Preloaded realistic campus orders & complaints
│   └── app.js            # Routing, state, tracking, staff actions, modals & toasts
└── README.md             # Project documentation
```

---

## 🏃 How to Run the Prototype

### Option 1: Direct Browser Launch
1. Open the project folder in Windows Explorer:
   `C:\Users\abhis\.gemini\antigravity\scratch\laundry-day-roulette`
2. Double-click `index.html` to open it in Chrome, Edge, or Firefox.

### Option 2: Run with VS Code Live Server
1. Open the folder in VS Code.
2. Right-click `index.html` and click **"Open with Live Server"**.

---

## 🧪 Demo Test IDs Included
The prototype comes preloaded with realistic orders for instant demonstration:
- **`LDR-1021`**: In `Washing` stage (Machine #3, Spin cycle)
- **`LDR-1022`**: In `Ready for pickup` stage (Rack C-12)
- **`LDR-1023`**: In `Collected` intake stage
- **`LDR-1018`**: In `Delivered` stage (with sample complaint `CMP-401` under investigation)
